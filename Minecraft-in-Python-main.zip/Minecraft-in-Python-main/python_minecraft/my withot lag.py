from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random

# ---------------- APP ----------------
app = Ursina()
application.target_fps = 60        # use 30 if PC is very weak
window.vsync = False
window.fps_counter.enabled = True

# ---------------- ASSETS ----------------
textures = {
    1: load_texture("Assets/Textures/Grass.png"),
    2: load_texture("Assets/Textures/Brick.png"),
}

sky_tex = load_texture("Assets/Textures/Sky.png")
build_sound = Audio("Assets/SFX/Build_Sound.wav", autoplay=False)

block_pick = 1

# ---------------- BLOCK ----------------
class Block(Entity):
    def __init__(self, position=(0,0,0), texture=textures[1], breakable=True):
        super().__init__(
            parent=scene,
            position=position,
            model="cube",              # MUCH faster than custom OBJ
            origin_y=0.5,
            texture=texture,
            scale=0.5,
            collider="box"
        )
        self.breakable = breakable

    def input(self, key):
        if mouse.hovered_entity == self:
            if key == "left mouse down":
                build_sound.play()
                Block(
                    position=self.position + mouse.normal,
                    texture=textures[block_pick]
                )

            if key == "right mouse down" and self.breakable:
                build_sound.play()
                destroy(self)

# ---------------- SKY ----------------
class Sky(Entity):
    def __init__(self):
        super().__init__(
            parent=scene,
            model="sphere",
            texture=sky_tex,
            scale=150,
            double_sided=True
        )

# ---------------- TREE (LOW POLY) ----------------
class Tree(Entity):
    def __init__(self, position=(0,0,0)):
        super().__init__(
            parent=scene,
            position=position,
            model="Assets/Models/Lowpoly_tree_sample.obj",
            scale=0.6,
            collider=None
        )

# ---------------- WORLD ----------------
def generate_terrain():
    size = 20
    height = 5

    for x in range(size):
        for z in range(size):
            for y in range(height):
                tex = textures[1] if y == height-1 else textures[2]
                Block(position=(x,y,z), texture=tex)

            Block(position=(x,-1,z), texture=textures[2], breakable=False)

def generate_trees(count=5):
    for _ in range(count):
        x = random.randint(0,19)
        z = random.randint(0,19)
        Tree(position=(x,1,z))

# ---------------- PLAYER ----------------
player = FirstPersonController(position=(10,10,10))
player.cursor.visible = False
player.gravity = 0.6   # lower gravity = smoother movement

# ---------------- UPDATE ----------------
def update():
    global block_pick

    for i in range(1,3):
        if held_keys[str(i)]:
            block_pick = i

    if held_keys["escape"]:
        application.quit()

    if player.y < -10:
        player.position = (10,10,10)

# ---------------- LIGHT ----------------
DirectionalLight(y=2, z=3)
AmbientLight(color=color.rgb(130,130,130))

# ---------------- START ----------------
Sky()
generate_terrain()
generate_trees()

app.run()

