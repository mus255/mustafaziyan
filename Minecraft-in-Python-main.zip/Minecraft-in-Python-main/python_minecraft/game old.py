from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()

# load all assets
textures = {
    1: load_texture("assets\textures\grass1.png"),
    2: load_texture("textures\brick.png"),
    }

sky_bg = load_texture(r"C:\Users\SD\AppData\Local\Programs\Python\Python311\Lib\site-packages\ursina\textures\sky_sunset.png")
build_sound = Audio(r"C:\Users\SD\AppData\Local\Programs\Python\Python311\Lib\site-packages\ursina\audio\sine.wav", loop=False, auto=False)



class Block(Button):
    def __init__(self, position=(0,0,0), texture=textures[1], breakable=True):
        super().__init__(
            parent=scene,
            position=position,
            model="Assets/Models/Block.obj",
            origin_y=0.5,
            texture=texture,
            color=color.gray,
            highlight_color=color.light_gray,
            scale=0.5
        )
        self.breakable = breakable

    
    def input(self, key):
        if self.hovered:
            if key == "left mouse down":
                build_sound.play()
                new_block = Block(position=self.position + mouse.normal, texture=textures[block_pick])
            elif key == "right mouse down" and self.breakable:
                build_sound.play()
                destroy(self)
        


Sky = Entity(
        parent=scene,
        model="sphere",
        texture="sky_sunset",
        scale=200,
        double_sided=True
        )




Wall1 = Entity(
    
    model="cube",
    texture="brick",
    collider="cube",
    scale=(20,10,5),
    position=(9.5,5,21),
    color=color.gray
    )    
            
            
            
        

for z in range(20):
    for x in range(20):
        block = Block(position=(x,0,z))
        bedrock = Block(position=(x,-1,z), texture=textures[2], breakable=False)







 




# update / input
def update():
    global block_pick
    for i in range(1,6):
        if held_keys[str(i)]:
            block_pick = i
            break
    
    
    if held_keys["escape"]:
        application.quit()   
    if player.y <= -5:
        player.position = (10,10,10)


player = FirstPersonController(position=(10,10,10))
player.cursor.visible = True





if __name__ == "__main__":
    app.run()
